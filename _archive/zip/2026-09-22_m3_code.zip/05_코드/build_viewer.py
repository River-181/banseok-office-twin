"""office_3F.glb + floorplan_3F.json -> viewer/index.html (single self-contained file)."""
import base64
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
glb = (ROOT / "07_산출물" / "glb" / "office_3F.glb").read_bytes()
model = json.loads((ROOT / "04_데이터" / "floorplan_3F.json").read_text(encoding="utf-8"))

rooms = {r["id"]: r["name"] for r in model["rooms"]}
info = {}
for f in model["furniture"]:
    where = rooms.get(f.get("room") or f.get("zone"), "")
    info[f["id"]] = dict(label=f["label"], where=where, equip=f.get("equip", []))
labels = [dict(name=r["name"], x=sum(p[0] for p in r["poly"]) / len(r["poly"]) / 100,
               z=sum(p[1] for p in r["poly"]) / len(r["poly"]) / 100) for r in model["rooms"]]

html = (Path(__file__).parent / "viewer_template.html").read_text(encoding="utf-8")
html = (html.replace("__GLB__", base64.b64encode(glb).decode())
            .replace("__INFO__", json.dumps(info, ensure_ascii=False))
            .replace("__LABELS__", json.dumps(labels, ensure_ascii=False)))
out = Path(__file__).parent / "viewer" / "index.html"
out.write_text(html, encoding="utf-8")
print(f"{out.name}: {out.stat().st_size/1024:.0f} KB")
