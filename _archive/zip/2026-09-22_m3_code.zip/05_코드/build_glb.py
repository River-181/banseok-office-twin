"""floorplan_3F.json -> 07_산출물/glb/office_3F.glb (meters, Y-up, node name = JSON id)."""
import json
from pathlib import Path

import numpy as np
import trimesh
from trimesh.visual.material import PBRMaterial

ROOT = Path(__file__).resolve().parent.parent
MODEL = json.loads((ROOT / "04_데이터" / "floorplan_3F.json").read_text(encoding="utf-8"))
OUT = ROOT / "07_산출물" / "glb" / "office_3F.glb"
CEILING = MODEL["meta"]["defaults"]["ceiling"] / 100

def material(hex_color, alpha=1.0, rough=0.8):
    rgb = [int(hex_color[i:i+2], 16) for i in (0, 2, 4)]
    return PBRMaterial(baseColorFactor=rgb + [int(alpha * 255)], roughnessFactor=rough, metallicFactor=0.0,
                       alphaMode="BLEND" if alpha < 1 else "OPAQUE", doubleSided=alpha < 1)

MAT = dict(EXT=material("2f3e4e"), CORE=material("8a8a8a"), GYP=material("e8e4dc"), frame=material("9aa5b1"),
           glass=material("8fd0f7", 0.28, 0.1), film=material("d6ecf7", 0.6, 0.3), floor=material("cfc8b8"),
           desk=material("c9b79c"), table=material("d9c7a3"), round_table=material("d9c7a3"), cabinet=material("9e9686"),
           locker=material("9e9686"), printer=material("f4f4f4"), mfp=material("f4f4f4"), shredder=material("eeeeee"),
           fridge=material("f5f5f5"), water_dispenser=material("dfe9f0"), sink_counter=material("b0bec5"),
           partition_shelf=material("8d6e63"), partition=material("8d6e63"), reception=material("b39a6b"),
           equipment_rack=material("333333"), desk_panel=material("5c6b73"), column=material("777777"),
           chair_task=material("2d3540"), chair_meeting=material("6d7b8a"), screen=material("8d6e63"), desk_screen=material("7fa3a8"))

scene = trimesh.Scene()

def box(x0, z0, x1, z1, y0, y1):
    m = trimesh.creation.box(extents=[max(x1 - x0, 0.01), y1 - y0, max(z1 - z0, 0.01)])
    m.apply_translation([(x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2])
    return m

def add(name, parts, mat):
    mesh = trimesh.util.concatenate(parts) if isinstance(parts, list) else parts
    mesh.visual = trimesh.visual.TextureVisuals(material=mat)
    scene.add_geometry(mesh, node_name=name, geom_name=name)

def wall_slices(kind):
    if kind == "EXT":
        return [(0, 0.85, "EXT"), (0.85, 2.45, "glass"), (2.45, CEILING, "EXT")]
    if kind == "GLS":
        return [(0, 0.9, "frame"), (0.9, CEILING, "glass")]
    if kind == "GLS_FILM":
        return [(0, 1.0, "glass"), (1.0, 1.7, "film"), (1.7, CEILING, "glass")]
    return [(0, CEILING, kind)]

def segments(a, b, door_spans):
    horizontal = a[1] == b[1]
    s0, s1 = sorted([a[0], b[0]] if horizontal else [a[1], b[1]])
    fixed = a[1] if horizontal else a[0]
    cur, solid, headers = s0, [], []
    for d0, d1 in sorted(door_spans):
        if d0 > cur:
            solid.append((cur, d0))
        headers.append((d0, d1))
        cur = max(cur, d1)
    if cur < s1:
        solid.append((cur, s1))
    return horizontal, fixed, solid, headers

def slab(horizontal, fixed, s0, s1, t, y0, y1):
    a, b, k, r = s0 / 100, s1 / 100, fixed / 100, t / 200
    return box(a, k - r, b, k + r, y0, y1) if horizontal else box(k - r, a, k + r, b, y0, y1)

doors_by_wall = {}
for d in MODEL["doors"]:
    doors_by_wall.setdefault(d["wall"], []).append((d["span"], d["h"] / 100))

for w in MODEL["walls"]:
    pieces = [(w["poly"][i], w["poly"][i + 1]) for i in range(len(w["poly"]) - 1)] if "poly" in w else [(w["a"], w["b"])]
    for n, (a, b) in enumerate(pieces):
        spans = doors_by_wall.get(w["id"], []) if "a" in w else []
        horizontal, fixed, solid, headers = segments(a, b, [s for s, _ in spans])
        by_mat = {}
        for s0, s1 in solid:
            for y0, y1, m in wall_slices(w["type"]):
                by_mat.setdefault(m, []).append(slab(horizontal, fixed, s0, s1, w["t"], y0, y1))
        for (s0, s1), (_, door_h) in zip(headers, sorted(spans)):
            head_mat = "GYP" if w["type"] in ("GLS", "GLS_FILM", "GYP") else w["type"]
            by_mat.setdefault(head_mat, []).append(slab(horizontal, fixed, s0, s1, w["t"], min(door_h, CEILING - 0.05), CEILING))
        for m, parts in by_mat.items():
            add(f'{w["id"]}_{n}_{m}', parts, MAT[m])

add("FLOOR", [box(-0.15, -0.15, 21.5, 15.7, -0.02, 0), box(9.15, -1.75, 12.25, 0, -0.02, 0)], MAT["floor"])

def desk_like(f):
    x0, z0, x1, z1 = f["x"] / 100, f["y"] / 100, (f["x"] + f["w"]) / 100, (f["y"] + f["d"]) / 100
    top = f["h"] / 100
    parts = [box(x0, z0, x1, z1, top - 0.03, top)]
    if f["w"] >= f["d"]:
        parts += [box(x0 + .03, z0 + .03, x0 + .06, z1 - .03, 0, top - .03), box(x1 - .06, z0 + .03, x1 - .03, z1 - .03, 0, top - .03)]
    else:
        parts += [box(x0 + .03, z0 + .03, x1 - .03, z0 + .06, 0, top - .03), box(x0 + .03, z1 - .06, x1 - .03, z1 - .03, 0, top - .03)]
    return parts

def round_table(f):
    r, cx, cz, top = f["w"] / 200, (f["x"] + f["w"] / 2) / 100, (f["y"] + f["d"] / 2) / 100, f["h"] / 100
    plate = trimesh.creation.cylinder(radius=r, height=0.04, sections=32)
    plate.apply_translation([0, 0, 0]); plate.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0]))
    plate.apply_translation([cx, top - 0.02, cz])
    leg = trimesh.creation.cylinder(radius=0.04, height=top - 0.04, sections=12)
    leg.apply_transform(trimesh.transformations.rotation_matrix(np.pi / 2, [1, 0, 0])); leg.apply_translation([cx, (top - 0.04) / 2, cz])
    return [plate, leg]

def chair(f):
    x0, z0, s, p, t = f["x"] / 100, f["y"] / 100, f["w"] / 100, 0.05, 0.05
    top = f["h"] / 100
    parts = [box(x0 + p, z0 + p, x0 + s - p, z0 + s - p, 0.42, 0.47),
             box(x0 + s / 2 - .03, z0 + s / 2 - .03, x0 + s / 2 + .03, z0 + s / 2 + .03, 0, 0.42)]
    back = dict(N=(x0 + p, z0 + s - p - t, x0 + s - p, z0 + s - p), S=(x0 + p, z0 + p, x0 + s - p, z0 + p + t),
                E=(x0 + p, z0 + p, x0 + p + t, z0 + s - p), W=(x0 + s - p - t, z0 + p, x0 + s - p, z0 + s - p))[f["face"]]
    return parts + [box(*back, 0.47, top)]

for f in MODEL["furniture"]:
    kind = f["type"]
    if kind == "chair":
        add(f["id"], chair(f), MAT[f"chair_{f['kind']}"])
    elif kind == "round_table":
        add(f["id"], round_table(f), MAT[kind])
    elif kind in ("desk", "table"):
        add(f["id"], desk_like(f), MAT[kind])
    else:
        add(f["id"], box(f["x"] / 100, f["y"] / 100, (f["x"] + f["w"]) / 100, (f["y"] + f["d"]) / 100, 0, f["h"] / 100), MAT[kind])

for c in MODEL["columns"]:
    add(c["id"], box(c["x"] / 100, c["y"] / 100, (c["x"] + c["w"]) / 100, (c["y"] + c["d"]) / 100, 0, CEILING), MAT["column"])

for p in MODEL["partitions"]:
    (ax, az), (bx, bz) = p["a"], p["b"]
    on_desk = p["type"] == "desk_screen"
    r = 0.015 if on_desk else 0.02
    add(p["id"], box(min(ax, bx) / 100 - r, min(az, bz) / 100 - r, max(ax, bx) / 100 + r, max(az, bz) / 100 + r,
                     0.72 if on_desk else 0, p["h"] / 100), MAT[p["type"]])

OUT.parent.mkdir(parents=True, exist_ok=True)
scene.export(OUT)
print(f"{OUT.name}: {len(scene.geometry)} nodes, {OUT.stat().st_size/1024:.0f} KB")
